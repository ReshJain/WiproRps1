package com.wipro.Database_Microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
